package ca.queensu.cs.cisc124.notes.comparable.geometry;

/**
 * A minimal version of the {@code Point2} class that demonstrates how to
 * implement the {@code Comparable} interface.
 */
public class Point2 implements Comparable<Point2> {

	private double x;
	private double y;

	/**
	 * Initializes the coordinates of this point to {@code (x, y)} where {@code x}
	 * and {@code y} are specified by the caller.
	 *
	 * @param x the x value of this point
	 * @param y the y value of this point
	 */
	public Point2(double x, double y) {
		this.x = x;
		this.y = y;
	}

	/**
	 * Compares this point to the specified object. The result is {@code true} if
	 * and only if the argument is not {@code null} and is a {@code Point2} object
	 * that has the same x and y coordinates as this object.
	 * 
	 * @param obj the object to compare this point against
	 * @return true if the given object represents a Point2 with the same x and y
	 *         coordinates as this point, false otherwise
	 */
	@Override
	public boolean equals(Object obj) {
		if (this == obj) {
			return true;
		}
		if (!(obj instanceof Point2)) {
			return false;
		}
		Point2 other = (Point2) obj;
		if (Double.compare(this.x, other.x) == 0 && Double.compare(this.y, other.y) == 0) {
			return true;
		}
		return false;
	}

	/**
	 * Returns a hash code for this point computed using the coordinates of this
	 * point.
	 * 
	 * @return a hash code for this point
	 */
	@Override
	public int hashCode() {
		int result = Double.hashCode(this.x);
		int c = Double.hashCode(this.y);
		result = 31 * result + c;
		return result;
	}

	/**
	 * Compares this point to another point using their distances from the origin.
	 * The result is a positive integer if this point is further from the origin
	 * than the other point, a negative integer if this point is closer to the
	 * origin than the other point, and zero if both points are equidistant to the
	 * origin.
	 * 
	 * @param other the other counter to compare to
	 * @return a positive integer if this point is further from the origin than the
	 *         other point, a negative integer if this point is closer to the origin
	 *         than the other point, and zero if both points are equidistant to the
	 *         origin
	 */
	@Override
	public int compareTo(Point2 other) {
		double thisDist = Math.hypot(this.x, this.y);
		double otherDist = Math.hypot(other.x, other.y);
		if (thisDist > otherDist) {
			return 1;
		} else if (otherDist > thisDist) {
			return -1;
		} else {
			return 0;
		}
	}

}
