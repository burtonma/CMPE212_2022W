package ca.queensu.cs.cisc124.notes.inheritance;

/**
 * A counter that stops counting at {@code Integer.MAX_VALUE}.
 *
 */
public class StoppingCounter extends Counter {
    // no fields!
    
    /**
     * Initialize this counter to a count of zero.
     */
    public StoppingCounter() {
        this(0);
    }
    
    /**
     * Initialize this counter to the specified count value.
     * 
     * @param value the count value of this counter
     */
    public StoppingCounter(int value) {
        super(value);
    }
    
    /**
     * Increment the value of this counter upwards by 1 stopping when the
     * count reaches {@code Integer.MAX_VALUE}.
     */
    @Override
    public void advance() {
        if (this.value() != Integer.MAX_VALUE) {     // use value() method to get value
            super.advance();                         // use Counter.advance() to increment the count
        }
    }
    
}