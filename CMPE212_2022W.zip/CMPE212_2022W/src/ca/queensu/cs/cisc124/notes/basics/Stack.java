package ca.queensu.cs.cisc124.notes.basics;

import java.util.ArrayList;
import java.util.List;

/**
 * A {@code Stack} represents a last-in-first-out (LIFO) stack of
 * strings. In addition to the usual push and pop methods, this class
 * allows the user to get the number of strings in a stack and to query
 * if the stack is empty.
 */
public class Stack {

    private List<String> elems;
    
    /**
     * Initialize this stack as an empty stack.
     */
    public Stack() {
        this.elems = new ArrayList<>();
    }

    /**
     * Returns the number of elements in this stack.
     * 
     * @return the number of elements in this stack
     */
    public int size() {
        return this.elems.size();
    }
    
    /**
     * Returns {@code true} if this stack contains no elements. The default
     * implementation simply returns {@code size() == 0}.
     * 
     * @return true if this stack contains no elements
     */
    public boolean isEmpty() {
    	return this.size() == 0;
    }

    /**
     * Pushes the specified element on to the top of this stack.
     * 
     * @param elem the element to be pushed on to the top of this stack
     */
    public void push(String elem) {
        this.elems.add(elem);
    }

    /**
     * Removes the element on the top of this stack and returns the element.
     * 
     * @return the top element of this stack
     * @throws RuntimeException if the stack is empty
     */
    public String pop() {
        String elem = this.elems.remove(this.size() - 1);
        return elem;
    }

    /**
     * Returns a string representation of this stack.
     * 
     * @return a string representation of this stack
     */
    public String toString() {
    	StringBuilder b = new StringBuilder("Stack:");
        if (this.size() != 0) {
            for (int i = this.size() - 1; i >= 0; i--) {
                b.append('\n');
                b.append(this.elems.get(i));
            }
        }
        return b.toString();
    }
}


