package ca.queensu.cs.cisc124.notes.interfaces;

/**
 * Simple demonstration of the {@code Function1} interface.
 *
 */
public class Function1Test {

	public static void evalAll(Function1[] arr, double x) {
		for (Function1 f : arr) {
			double y = f.eval(x);
			String s = String.format("%s: f(%f) = %f", f.toString(), x, y);
			System.out.println(s);
		}
	}
	
	public static void main(String[] args) {
		Function1[] funcs = new Function1[3];
		funcs[0] = new Square();
		funcs[1] = new TruncatedSquare();
		funcs[2] = new Linear(0.5, -0.33);
		
		evalAll(funcs, 0.5);
		System.out.println();

		evalAll(funcs, -3.0);
	}

}
