package ca.queensu.cs.cisc124.notes.generics.basics;

import java.util.Arrays;

/**
 * An array-based implementation of a stack.
 *
 * @param <E> the type of elements in this stack
 */
public class ArrayStack<E> implements Stack<E> {
    
	// the initial capacity of the stack
    private static final int DEFAULT_CAPACITY = 16;

    // the array that stores the stack
    private Object[] arr;

    // the index of the top of the stack (equal to -1 for an empty stack)
    private int top;

    
    /**
     * Initialize an empty stack.
     */
    public ArrayStack() {
        this.arr = new Object[ArrayStack.DEFAULT_CAPACITY];
        this.top = -1;
    }

    /**
     * Returns the number of elements in this stack.
     * 
     * @return the number of elements in this stack
     */
    public int size() {
    	return this.top + 1;
    }

    /**
     * Pushes the specified element on to the top of this stack.
     * 
     * @param elem the element to be pushed on to the top of this stack
     */
    public void push(E elem) {
    	// do we need to resize the array?
        if (this.size() == this.arr.length) {
            this.arr = Arrays.copyOf(this.arr, this.arr.length * 2);
        }
        this.top++;
        this.arr[this.top] = elem;
    }

    /**
     * Removes the element on the top of this stack and returns the element.
     * 
     * @return the top element of this stack
     * @throws RuntimeException if the stack is empty
     */
    public E pop() {
    	// is the stack empty?
        if (this.isEmpty()) {
            throw new RuntimeException("popped an empty stack");
        }
        // get the element at the top of the stack as type E
        E element = (E) this.arr[this.top];
        
        // null out the value stored in the array
        this.arr[this.top] = null;

        // adjust the top of stack index
        this.top--;

        // return the element that was on the top of the stack
        return element;
    }

    /**
     * Returns a string representation of this stack. The elements of the stack
     * appear in the returned string in sequence starting from the top of the
     * stack to the bottom of the stack with each element separated from the
     * next using a newline character.
     * 
     * @return a string representation of this stack
     */
    @Override
    public String toString() {
    	StringBuilder b = new StringBuilder("Stack:");
        if (this.size() != 0) {
            for (int i = this.size() - 1; i >= 0; i--) {
                b.append('\n');
                b.append(this.arr[i]);
            }
        }
        return b.toString();
    }
    

    public static void main(String[] args) {
        Stack<String> t = new LinkedStack<>();
        t.push("A");
        t.push("B");
        t.push("C");
        System.out.println("size: " + t.size());
        System.out.println(t);
        System.out.println();
        
        String popped = t.pop();
        System.out.println("popped: " + popped);
        System.out.println("size: " + t.size());
        System.out.println(t);
        System.out.println();
        
        popped = t.pop();
        System.out.println("popped: " + popped);
        System.out.println("size: " + t.size());
        System.out.println(t);
        System.out.println();
        
        popped = t.pop();
        System.out.println("popped: " + popped);
        System.out.println("size: " + t.size());
        System.out.println(t);
        System.out.println();
        
        // force an exception
        t.pop();
    }
}