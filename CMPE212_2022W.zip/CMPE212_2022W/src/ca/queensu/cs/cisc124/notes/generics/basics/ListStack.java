package ca.queensu.cs.cisc124.notes.generics.basics;

import java.util.ArrayList;

/**
 * An {@code ArrayList}-based implementation of a stack.
 *
 * @param <E> the type of elements in this stack
 */
public class ListStack<E> implements Stack<E> {
    
    private ArrayList<E> stack;
    
    /**
     * Initialize an empty stack.
     */
    public ListStack() {
        this.stack = new ArrayList<>();
    }

    /**
     * Returns the number of elements in this stack.
     * 
     * @return the number of elements in this stack
     */
    public int size() {
        return this.stack.size();
    }

    /**
     * Pushes the specified element on to the top of this stack.
     * 
     * @param elem the element to be pushed on to the top of this stack
     */
    public void push(E elem) {
        this.stack.add(elem);
    }

    /**
     * Removes the element on the top of this stack and returns the element.
     * 
     * @return the top element of this stack
     * @throws RuntimeException if the stack is empty
     */
    public E pop() {
        E elem = this.stack.remove(this.size() - 1);
        return elem;
    }

    /**
     * Returns a string representation of this stack. The elements of the stack
     * appear in the returned string in sequence starting from the top of the
     * stack to the bottom of the stack with each element separated from the
     * next using a newline character.
     * 
     * @return a string representation of this stack
     */
    @Override
    public String toString() {
        StringBuilder b = new StringBuilder("Stack:");
        if (this.size() != 0) {
            for (int i = this.size() - 1; i >= 0; i--) {
                b.append('\n');
                b.append(this.stack.get(i));
            }
        }
        return b.toString();
    }
}