package ca.queensu.cs.cisc124.notes.turtle;

import ca.queensu.cs.cisc124.notes.basics.geometry.Point2;
import java.awt.Color;
import java.util.ArrayList;
import java.util.List;

public class DragonCurve {

	private static void dragon(List<Turtle> turtles, double length, int n) {
		if (n == 0) {
			for (Turtle t : turtles) {
				t.forward(length);
			}
		} else {
			for (Turtle t : turtles) {
				t.turnRight(45.0);
			}
			dragon(turtles, length / Math.sqrt(2.), n - 1);
			for (Turtle t : turtles) {
				t.turnLeft(90.0);
			}
			reverseDragon(turtles, length / Math.sqrt(2.), n - 1);
			for (Turtle t : turtles) {
				t.turnLeft(45.0);
			}
		}
	}

	private static void reverseDragon(List<Turtle> turtles, double length, int n) {
		if (n == 0) {
			for (Turtle t : turtles) {
				t.forward(length);
			}
		} else {
			for (Turtle t : turtles) {
				t.turnRight(45.0);
			}
			dragon(turtles, length / Math.sqrt(2.), n - 1);
			for (Turtle t : turtles) {
				t.turnRight(90.0);
			}
			reverseDragon(turtles, length / Math.sqrt(2.), n - 1);
			for (Turtle t : turtles) {
				t.turnLeft(45.0);
			}
		}
	}

	public static void main(String[] args) {
		List<Turtle> turtles = new ArrayList<Turtle>();
		turtles.add(new Turtle(new Point2(0.5, 0.5), 0.0, new Pen()));
		for (int i = 1; i < 4; i++) {
			Turtle u = new Turtle(turtles.get(i - 1));
			u.turnLeft(90.0);
			turtles.add(u);
		}
		turtles.get(1).pen().setColor(Color.RED);
		turtles.get(2).pen().setColor(Color.BLUE);
		turtles.get(3).pen().setColor(Color.GRAY);
		dragon(turtles, 0.5, 12);
	}
}
