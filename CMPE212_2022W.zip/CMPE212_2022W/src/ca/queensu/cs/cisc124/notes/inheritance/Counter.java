package ca.queensu.cs.cisc124.notes.inheritance;

/**
 * A base class for counters that are able to count upwards in increments of 1.
 * This class resets the count to zero at {@code Integer.MAX_VALUE} without reporting an error.
 * Subclasses may change the way the counter behaves when it reaches the
 * limits of the range of the counter.
 *
 */
public class Counter {

    protected int value;    // changed access modifier to protected
    
    /**
     * Initializes the value of this counter to be equal to zero.
     */
    public Counter() {
        this.value = 0;
    }
    
    /**
     * Initializes the value of this counter to the specified value.
     *
     * @param value the initial value of this counter
     */
    public Counter(int value) {
        this.value = value;
    }
    
    /**
     * Initializes the value of this counter by copying the value
     * from the specified counter.
     *
     * @param other the counter to copy
     */
    public Counter(Counter other) {
        this.value = other.value;
    }
    
    /**
     * Returns the current value of this counter.
     * 
     * @return the current value of this counter
     */
    public int value() {
        return this.value;
    }
    
    /**
     * Increment the value of this counter upwards by 1. Subclasses
     * may override this method to change its behaviour at the limits
     * of the range of the counter.
     *
     * <p>
     * If this method is called when the current value of this counter is equal to
     * {@code Integer.MAX_VALUE} then the value of this counter is
     * set to 0 (i.e., the counter wraps around to 0).
     *
     * @throws RuntimeException if the counter cannot be advanced
     *         and the subclass chooses to throw an exception
     */
    public void advance() {
        if (this.value != Integer.MAX_VALUE) {
            this.value++;
        }
        else {
            this.value = 0;
        }
    }
    
    /**
     * Compares this counter to the specified object. The result is {@code true} if
     * and only if the argument is not {@code null} and is a {@code Counter} object
     * that has the same current value as this object.
     * 
     * @param obj the object to compare this counter against
     * @return true if the given object represents a Counter with the same current
     *         value as this counter, false otherwise
     */
    @Override
    public boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (!(obj instanceof Counter)) {
            return false;
        }
        Counter other = (Counter) obj;
        if (this.value == other.value) {
            return true;
        }
        return false;
    }
    
    /**
     * Returns a hash code for this counter.
     *
     * @return a hash code for this counter
     */
    @Override
    public int hashCode() {
        int result = Integer.hashCode(this.value);

        return result;
    }
    
    /**
     * Returns a string representation of this counter. The string representation is
     * the string {@code "count: "} followed by the current value of this counter.
     * 
     * @return a string representation of this counter
     */
    @Override
    public String toString() {
        return "count: " + this.value;
    }
}