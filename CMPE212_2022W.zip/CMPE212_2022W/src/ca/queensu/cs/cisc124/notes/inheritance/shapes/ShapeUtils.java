package ca.queensu.cs.cisc124.notes.inheritance.shapes;

public class ShapeUtils {

	/**
	 * Randomly scale the width and height of the specified shape by a small
	 * amount. The change in width and height is less than 1 percent of the
	 * current width and height. The width and height of the shape are scaled by different
	 * random amounts.
	 * 
	 * @param s the shape to scale
	 */
	public static void randomScale(Shape s) {
        // randomly scales the width and height of a shape by a small amount (less than 1%)
        // Math.random() returns a random value between 0 and 1
        double w = s.width() * (1.0 + (Math.random() * 0.01 - 0.005));
        double h = s.height() * (1.0 + (Math.random() * 0.01 - 0.005));
        s.setDimensions(w, h);
    }
}
