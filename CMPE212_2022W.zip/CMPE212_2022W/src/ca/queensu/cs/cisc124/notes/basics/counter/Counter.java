package ca.queensu.cs.cisc124.notes.basics.counter;

import java.util.Objects;

/**
 * The {@code Counter} class represents a device used to incrementally count
 * upwards from zero up to {@code Integer.MAX_VALUE}.
 *
 */
public class Counter {

	/**
	 * The current value of this counter.
	 */
	private int value;
	
	/**
	 * Initializes this counter so that its current value is 0.
	 */
	public Counter() {
		this.value = 0;
	}
	
	/**
	 * Returns the current value of this counter.
	 * 
	 * @return the current value of this counter
	 */
	public int value() {
		return this.value;
	}
	
	/**
	 * Increment the value of this counter upwards by 1. If this method
	 * is called when the current value of this counter is equal to
	 * {@code Integer.MAX_VALUE} then the value of this counter is
	 * set to 0 (i.e., the counter wraps around to 0).
	 */
	public void advance() {
		if (this.value != Integer.MAX_VALUE) {
			this.value++;
		}
		else {
			this.value = 0;
		}
	}
	
	/**
	 * Returns a hash code for this counter.
	 * 
	 * @return a hash code for this counter
	 */
	@Override
	public int hashCode() {
		return Objects.hash(this.value);
	}

	/**
	 * Compares this counter to the specified object. The result is {@code true} if
	 * and only if the argument is not {@code null} and is a {@code Counter} object
	 * that has the same current value as this object.
	 * 
	 * @param obj the object to compare this counter against
	 * @return true if the given object represents a Counter with the same current
	 *         value to this counter, false otherwise
	 */
	@Override
	public boolean equals(Object obj) {
		if (this == obj) {
			return true;
		}
		if (obj == null) {
			return false;
		}
		if (this.getClass() != obj.getClass()) {
			return false;
		}
		Counter other = (Counter) obj;
		return this.value == other.value;
	}
	
	/**
	 * Returns a string representation of this counter. The string
	 * representation is the string {@code "count: "} followed
	 * by the current value of this counter.
	 * 
	 * @return a string representation of this counter
	 */
	@Override
	public String toString() {
		return "count: " + this.value;
	}
	
} // end of Counter class
