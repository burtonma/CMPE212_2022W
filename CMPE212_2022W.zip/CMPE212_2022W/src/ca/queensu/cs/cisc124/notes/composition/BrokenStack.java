package ca.queensu.cs.cisc124.notes.composition;

import java.util.ArrayList;
import java.util.List;

/**
 * A stack class that exposes a reference to its internal list.
 *
 */
public class BrokenStack {

    private List<String> elems;
    
    /**
     * Initializes an empty stack.
     */
    public BrokenStack() {
        this.elems = new ArrayList<>();
    }

    /**
     * Returns the number of elements in this stack.
     * 
     * @return the number of elements in this stack
     */
    public int size() {
        return this.elems.size();
    }
    
    /**
     * Returns {@code true} if this stack contains no elements. The default
     * implementation simply returns {@code size() == 0}.
     * 
     * @return true if this stack contains no elements
     */
    public boolean isEmpty() {
    	return this.size() == 0;
    }

    /**
     * Pushes the specified element on to the top of this stack.
     * 
     * @param elem the element to be pushed on to the top of this stack
     */
    public void push(String elem) {
        this.elems.add(elem);
    }

    /**
     * Removes the element on the top of this stack and returns the element.
     * 
     * @return the top element of this stack
     * @throws RuntimeException if the stack is empty
     */
    public String pop() {
        String elem = this.elems.remove(this.size() - 1);
        return elem;
    }

    /**
     * Returns a reference to the list containing the elements of this stack.
     * 
     * @return a reference to the list containing the elements of this stack
     */
    public List<String> getElements() {
        return this.elems;
    }
    
    /**
     * Returns a string representation of this stack.
     * 
     * @return a string representation of this stack
     */
    public String toString() {
    	StringBuilder b = new StringBuilder("BrokenStack:");
        if (this.size() != 0) {
            for (int i = this.size() - 1; i >= 0; i--) {
                b.append('\n');
                b.append(this.elems.get(i));
            }
        }
        return b.toString();
    }
}
